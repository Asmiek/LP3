

<?php
/*

    ATIVIDADE 1 


$bat = 100;

while ($bat != -5 )
    {
        echo "O valor da varivel é $bat<br>";
        $bat = $bat - 5;
    }



    ATIVIDADE 2

$media = 0;
$i = 0;
$soma= 14;

while ($i < 60){

$media = $media + $soma;
$soma++;
$i++;

}

$media = $media / 60;

echo ("$media")

    ATIVIDADE 3     
*/

$bat = 30;

while ($bat  >=  0)
{


if($bat % 4 == 0 ){

echo ("[$bat]<br>");
}

else{
echo("$bat <br>");
}




$bat--;
}

?>