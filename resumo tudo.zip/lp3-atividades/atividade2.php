<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>

<body class="bg-warning-subtle d-flex justify-content-center align-items-center vh-100">
<div class="card text-center p-4 border-success">
    <?php 


$carro = $_POST['txtcarro'] ;
$dias = $_POST['txtdias'] ;
$km = $_POST['txtkm'] ;
$aluguel = 0;


if($carro == "popular")
    {
        if($km < 100)
            {
                $aluguel = 90 * $dias;
                 $aluguel = $aluguel + (0.20 * $km);
                
                 echo "R$ ";
                 echo number_format($aluguel,2,",",".");
            }

        if($km > 100)
            {
                 $aluguel = 90 * $dias;
                 $aluguel = $aluguel + (0.10 * $km);
            
                echo "R$ ";
                 echo number_format($aluguel,2,",",".");
            }      

    }


if($carro == "luxo")
    {
        if($km < 200)
            {
                $aluguel = 150 * $dias;
                 $aluguel = $aluguel + (0.30 * $km);
            
                echo "R$ ";
                 echo number_format($aluguel,2,",",".");
            }

        if($km > 200)
            {
                 $aluguel = 150 * $dias;
                 $aluguel = $aluguel + (0.25 * $km);
            
                echo "R$ ";
                 echo number_format($aluguel,2,",",".");
            }      

    }


?>
</div>





<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>     
</body>
</html>