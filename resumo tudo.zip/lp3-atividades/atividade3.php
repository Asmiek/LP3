<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade 3</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class= "bg-success-subtle d-flex justify-content-center align-items-center vh-100">
      
        <div class = "container card p-4 text-center" >


            <h2 class ="card p-4 text-success rounded-4 border-success">Resultado Atividades Saúde+</h2>
                <?php  
                    $pontos = 0;
                    $exer = $_POST['txtexer'];
                    if($exer < 10)
                        {
                            $pontos = $exer * 2;

                        }

                    if($exer >= 10 && $exer <= 20)
                        {
                            $pontos = $exer * 5;

                        }

                    if($exer > 20)
                        {
                            $pontos = $exer * 10;
                        }

                    $dinheiro = $pontos * 0.05;
                ?>

                    <div class="mt-5"></div>    


                <h4>Horas de atividades físicas praticadas:</h4>
                    <div class="mt-2"></div>


                    <span class="badge bg-primary fs-4 mb-3 rounded-4">
                        <?php echo $exer; ?> horas
                    </span>

                    <div class="mt-5"></div>


                    <h4>Pomtos obtidos:</h4>
                    <div class="mt-2"></div>


                    <span class="badge bg-warning  text-dark fs-4 mb-3 rounded-4">
                        <?php echo $pontos; ?> pontos
                    </span>

                    <div class="mt-5"></div>

                    <h4>Valor recebido:</h4>
                    <div class="mt-2"></div>

                    <div class="alert alert-success fs-4 fw-bold">
                    R$ <?php echo number_format($dinheiro,2,",","."); ?>
                    </div>


        </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>   
</body>
</html>