<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Resultado da Atividade</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="bg-success-subtle d-flex justify-content-center align-items-center vh-100">

<div class="container">

<div class="card p-4 text-center">

<h2 class="mb-4 text-success">Resultado do Programa Saúde+</h2>

<?php

$exer = $_POST['txtexer'];

if($exer <= 10){
    $pontos = $exer * 2;
}
else if($exer <= 20){
    $pontos = $exer * 5;
}
else{
    $pontos = $exer * 10;
}

$dinheiro = $pontos * 0.05;

?>

<p class="fs-4">Horas de atividade física:</p>

<span class="badge bg-primary fs-5 mb-3">
<?php echo $exer; ?> horas
</span>

<hr>

<p class="fs-4">Pontuação obtida:</p>

<span class="badge bg-warning text-dark fs-5 mb-3">
<?php echo $pontos; ?> pontos
</span>

<hr>

<p class="fs-4">Valor recebido:</p>

<div class="alert alert-success fs-4 fw-bold">
R$ <?php echo number_format($dinheiro,2,",","."); ?>
</div>


</div>
</div>

</body>
</html>