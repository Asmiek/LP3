<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <div class="container"> 
        <div class="row">

            <h1>Formularios</h1>

            <form action="recebedados.php" method="POST">

                <div class="mb-3">
                <label for="campoemail" class="form-label">Endereço de email</label>
                <input type="email" class="form-control" id="campoemail" placeholder="nome@exemplo" name="txtemail">
                </div>

                 <div class="mb-3">
                <label for="camponome" class="form-label">Nome completo</label>
                <input type="text" class="form-control" id="camponome" name="txtnome">
                </div>

                <div class="mb-3">
                <label for="textarea" class="form-label">Área de texto</label>
                <textarea class="form-control" id="textarea" rows="3" name="txtdescrição"> </textarea>
                </div>

                <button type="submit" class="btn btn-success">Enviar</button>
                <button type="reset" class="btn btn-warning">Limpar campos</button>

            </form>


        </div>


    </div>














<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>        
</body>
</html>